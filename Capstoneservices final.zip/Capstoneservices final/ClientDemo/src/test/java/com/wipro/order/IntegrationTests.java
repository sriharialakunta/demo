package com.wipro.order;

public class IntegrationTests {

}
