package com.wipro.capstone.service.util;

public class AppConstants {

	public static final String TOPIC_ADDPRODUCT = "ProductMicro";
	public static final String TOPIC_DELETEPRODUCT = "DeleteProductMicro";
	public static final String GROUP_ID = "group_id";
}
