package com.wipro.capstone.util;

public class AppConstants {

	public static final String TOPIC_ORDER = "OrderMicroservice";
	public static final String TOPIC_DELETEPRODUCT = "DeleteProductMicro";
	public static final String GROUP_ORDER = "Order_id";
	public static final String GROUP_ID = "Cart_id";
}
